Introduction to Zoology v5.6.3 — Native Android WebView Project

This is a minimal Android app wrapper around the audited offline v5.6.3 app.
No Capacitor, Cordova, CDN, hosting or internet permission is required.

Build in Android Studio:
1. Open this project folder.
2. Use JDK 21.
3. Install Android SDK Platform 36.
4. Build > Build APK(s).
5. Output: app/build/outputs/apk/debug/app-debug.apk

Or push this whole project to GitHub and run:
Actions > Build Android APK > Run workflow.

Package: com.gasczoology.introzoology
Version: 5.6.3 (563)
Minimum Android: API 24
Target Android: API 36
